package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.model.Product;
import com.model.Review;
import com.service.ReviewService;

@RestController
@RequestMapping("reviews")
@CrossOrigin(origins = { "http://localhost:3000", "http://localhost:4200" })
public class ReviewController {

	@Autowired
	ReviewService reviewService;
	Product product;

	// To fetch all Reviews of a particular product
	@GetMapping("/{productId}")
	public ResponseEntity<List<Review>> getAllReview(@PathVariable("productId") int productId) {
		System.out.println("Fetching all reviews");
		System.out.println(productId);
		List<Review> allReview = reviewService.getAllReview(productId);
		return new ResponseEntity<List<Review>>(allReview, HttpStatus.OK);
	}

	@PostMapping("/{productId}")
	public boolean saveReview(@RequestBody Review review, @PathVariable("productId") int productId) {
		System.out.println("saving review");
		reviewService.addReview(productId, review);

		return true;

	}

	@GetMapping("/{productId}/{reviewId}")
	public Review getReview(@PathVariable("productId") int productId, @PathVariable("reviewId") int reviewId) {
		System.out.println("Getting review " + reviewId);
		return reviewService.getReview(productId, reviewId);

	}

	@DeleteMapping("/{productId}/{reviewId}")
	public boolean deleteReview(@PathVariable("productId") int productId, @PathVariable("reviewId") int reviewId) {
		System.out.println("Deleting review " + reviewId);
		return reviewService.deleteReview(productId, reviewId);

	}
	
	@PutMapping("/{productId}")
	public boolean updateReview(@RequestBody Review review, @PathVariable("productId") int productId) {
		System.out.println("Updating review " + productId);
		return reviewService.updateReview(productId, review);

	}

}
