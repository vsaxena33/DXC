package com.dao;

import java.util.List;

import com.model.Review;

public interface ReviewDAO {

	public List<Review> getAllReview(int productId);

	public boolean addReview(int productId, Review review);
	
	public boolean deleteReview(int productId, int reviewId);
	
	public Review getReview(int productId, int reviewId);
	
	public boolean updateReview(int productId, Review review);

}
