package com.dxc.pms.entity;

import java.util.Set;

import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.search.annotations.IndexedEmbedded;

@Entity
@Table(name = "DoctorDetails")
public class Doctor {

	@Id
	@GeneratedValue(generator = "uuid")
	@GenericGenerator(name = "uuid", strategy = "uuid2")
	private int doctorId;
	private String doctorName;
	private int doctorFee;

	@ElementCollection
	@IndexedEmbedded
	private Set<HospitalDetails> hospitalDetails;

	public Doctor() {
		super();
	}

	public Doctor(int doctorId, String doctorName, int doctorFee) {
		super();
		this.doctorId = doctorId;
		this.doctorName = doctorName;
		this.doctorFee = doctorFee;
	}

	public int getDoctorId() {
		return doctorId;
	}

	public void setDoctorId(int doctorId) {
		this.doctorId = doctorId;
	}

	public String getDoctorName() {
		return doctorName;
	}

	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}

	public int getDoctorFee() {
		return doctorFee;
	}

	public void setDoctorFee(int doctorFee) {
		this.doctorFee = doctorFee;
	}

	public Set<HospitalDetails> getHospitalDetails() {
		return hospitalDetails;
	}

	public void setHospitalDetails(Set<HospitalDetails> hospitalDetails) {
		this.hospitalDetails = hospitalDetails;
	}

	public Doctor(int doctorId, String doctorName, int doctorFee, Set<HospitalDetails> hospitalDetails) {
		super();
		this.doctorId = doctorId;
		this.doctorName = doctorName;
		this.doctorFee = doctorFee;
		this.hospitalDetails = hospitalDetails;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + doctorFee;
		result = prime * result + doctorId;
		result = prime * result + ((doctorName == null) ? 0 : doctorName.hashCode());
		result = prime * result + ((hospitalDetails == null) ? 0 : hospitalDetails.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Doctor other = (Doctor) obj;
		if (doctorFee != other.doctorFee)
			return false;
		if (doctorId != other.doctorId)
			return false;
		if (doctorName == null) {
			if (other.doctorName != null)
				return false;
		} else if (!doctorName.equals(other.doctorName))
			return false;
		if (hospitalDetails == null) {
			if (other.hospitalDetails != null)
				return false;
		} else if (!hospitalDetails.equals(other.hospitalDetails))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Doctor [doctorId=" + doctorId + ", doctorName=" + doctorName + ", doctorFee=" + doctorFee
				+ ", hospitalDetails=" + hospitalDetails + "]";
	}

}
