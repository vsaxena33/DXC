package com.cms.app.dao;

import java.util.List;

import com.cms.app.model.Training;

public interface TrainingDAO {

		public List<Training> getAllTraining();
		public List<Training> getTrainingOneByOne();
}
