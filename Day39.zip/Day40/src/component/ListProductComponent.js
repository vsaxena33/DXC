import React, { Component } from 'react'
import ProductDataService from '../service/ProductDataService';

export default class ListProductComponent extends Component {

    constructor(props) {
        super(props)
        this.refreshProduct = this.refreshProduct.bind(this);
        this.deleteButtonClicked = this.deleteButtonClicked.bind(this);
        this.updateProductClicked = this.updateProductClicked.bind(this);
        this.addProductCliked = this.addProductCliked.bind(this);

        this.state = ({
            products: [],
            message: ''
        })
    }

    UNSAFE_componentWillMount() {
        this.refreshProduct();
    }

    deleteButtonClicked(productIdToDelete) {
        ProductDataService.deleteProduct(productIdToDelete).then(
            response => {
                this.setState({ message: `Delete of product ${productIdToDelete} Successful` })
                this.refreshProduct()
            }
        );
    }

    refreshProduct() {
        ProductDataService.getAllProducts().then(
            response => {
                this.setState({
                    products: response.data
                });
            }
        );
    }

    updateProductClicked(productIdtoUpdate) {
        this.props.history.push(`/products/${productIdtoUpdate}`)
    }

    addProductCliked() {
        this.props.history.push(`/products/add`)
    }

    render() {
        return (
            <div>
                <div className="container">
                    {this.state.message && <div className="alert alert-success">{this.state.message}</div>}
                    <table className="table">
                        <thead>
                            <tr>
                                <th>Product Id</th>
                                <th>Product Name</th>
                                <th>Quantity On Hand</th>
                                <th>Price</th>
                                <th>Delete</th>
                                <th>Update</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                this.state.products.map(product =>
                                    <tr key={product.productId}>
                                        <td>{product.productId}</td>
                                        <td>{product.productName}</td>
                                        <td>{product.quantityOnHand}</td>
                                        <td>{product.price}</td>
                                        <td>
                                            <button className="btn btn-outline-dark" onClick={() => this.deleteButtonClicked(product.productId)}>
                                                Delete
                                            </button>
                                        </td>
                                        <td>
                                            <button className="btn btn-outline-dark" onClick={() => this.updateProductClicked(product.productId)}>
                                                Update
                                            </button>
                                        </td>
                                    </tr>)
                            }
                        </tbody>
                    </table>
                </div>
                <div><button className="btn btn-success" onClick={() => this.addProductCliked()}>Add</button></div>
            </div>
        )
    }
}
