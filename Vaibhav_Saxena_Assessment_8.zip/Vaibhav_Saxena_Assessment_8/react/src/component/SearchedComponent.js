import React, { Component } from 'react';
import { Formik, Form, Field, ErrorMessage } from "formik";
class SearchComponent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      productName: ""
    };
    this.onsubmit = this.onsubmit.bind(this);
  }
  onsubmit(product) {
    this.props.history.push(`/productSearch/${product.productName}`);
    console.log(product.productName);
  }

  validateProductForm(values) {
    let errors = {};
    if (!values.productName) {
      errors.productName = "Please enter a product Name";
    }
    if (values.productName < 5) {
      errors.productName = "Please enter atleast 5 characters in productName";
    }
    return errors;
  }

  render() {
    let { productName } = this.state;
    return (
      <div className="container">
        <center>
          <h3>Product to Search</h3>
        </center>
        <Formik
          initialValues={{
            productName
          }}
          enableReinitialize={true}
          onSubmit={this.onsubmit}
          validateOnChange={false}
          validateOnBlur={false}
          validate={this.validateProductForm}
        >
          <Form>

            <ErrorMessage
              name="productName"
              component="div"
              className="alert alert-warning"
            ></ErrorMessage>

            <fieldset className="form-group">
              <label>Product Name</label>
              <Field
                className="form-control"
                type="text"
                name="productName"
              ></Field>
            </fieldset>
            <button className="btn btn-success" type="submit">
              Search
                </button>
          </Form>
        </Formik>
      </div>
    );
  }

}

export default SearchComponent;