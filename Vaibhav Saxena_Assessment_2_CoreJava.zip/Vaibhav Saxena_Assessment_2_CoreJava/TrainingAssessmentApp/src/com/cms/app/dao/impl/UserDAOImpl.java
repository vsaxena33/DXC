package com.cms.app.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cms.app.dao.UserDAO;
import com.cms.app.dbconnection.DBConnection;
import com.cms.app.model.Users;

public class UserDAOImpl implements UserDAO {

	Connection connection = DBConnection.getConnection();
	private static final String VALIDATE_User = "select * from users where username = ? and password = ?";

	@Override
	public boolean validateUser(Users users) {
		// TODO Auto-generated method stub
		boolean validation = false;
		PreparedStatement preparedStatement;
		try {
			preparedStatement = connection.prepareStatement(VALIDATE_User);
			preparedStatement.setString(1, users.getUserName());
			preparedStatement.setString(2, users.getPassword());
			ResultSet resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				validation = true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return validation;
	}

}
