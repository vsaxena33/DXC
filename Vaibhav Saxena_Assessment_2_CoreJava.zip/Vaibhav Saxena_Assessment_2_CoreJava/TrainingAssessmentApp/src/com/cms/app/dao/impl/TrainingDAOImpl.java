package com.cms.app.dao.impl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cms.app.dao.TrainingDAO;
import com.cms.app.dbconnection.DBConnection;
import com.cms.app.model.Training;

public class TrainingDAOImpl implements TrainingDAO {

	Connection connection = DBConnection.getConnection();
	private static final String FETCH_ALL = "select * from training";
	
	@Override
	public List<Training> getAllTraining() {
		// TODO Auto-generated method stub
		List<Training> allTraining = new ArrayList<Training>();
		try {
			Statement statement = connection.createStatement();
			ResultSet resultSets = statement.executeQuery(FETCH_ALL);
			while(resultSets.next()) {
				Training training = new Training();
				training.setSapId(resultSets.getInt(1));
				training.setEmployeeName(resultSets.getString(2));
				training.setStream(resultSets.getString(3));
				training.setPercentage(resultSets.getInt(4));
				allTraining.add(training);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return allTraining;
	}

	Scanner sc = new Scanner(System.in);
	@Override
	public List<Training> getTrainingOneByOne() {
		// TODO Auto-generated method stub
		List<Training> updateTraining = new ArrayList<Training>();
		try {
			Statement statement = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
			ResultSet resultSets = statement.executeQuery(FETCH_ALL);
			while(resultSets.next()) {
				System.out.println("Please enter percentage for : " + resultSets.getString(2));
				int percentage = sc.nextInt();
				
				resultSets.updateInt(4, percentage);
				resultSets.updateRow();
				
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return updateTraining;
	}

}
