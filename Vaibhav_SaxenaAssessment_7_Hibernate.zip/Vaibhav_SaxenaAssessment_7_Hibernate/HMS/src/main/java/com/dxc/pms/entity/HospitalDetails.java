package com.dxc.pms.entity;

import javax.persistence.Embeddable;

@Embeddable
public class HospitalDetails {
	
	private String hospitalName;
	private String hospitalCity;
	
	public HospitalDetails() {
		super();
	}

	public HospitalDetails(String hospitalName, String hospitalCity) {
		super();
		this.hospitalName = hospitalName;
		this.hospitalCity = hospitalCity;
	}

	public String getHospitalName() {
		return hospitalName;
	}

	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}

	public String getHospitalCity() {
		return hospitalCity;
	}

	public void setHospitalCity(String hospitalCity) {
		this.hospitalCity = hospitalCity;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((hospitalCity == null) ? 0 : hospitalCity.hashCode());
		result = prime * result + ((hospitalName == null) ? 0 : hospitalName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		HospitalDetails other = (HospitalDetails) obj;
		if (hospitalCity == null) {
			if (other.hospitalCity != null)
				return false;
		} else if (!hospitalCity.equals(other.hospitalCity))
			return false;
		if (hospitalName == null) {
			if (other.hospitalName != null)
				return false;
		} else if (!hospitalName.equals(other.hospitalName))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "HospitalDetails [hospitalName=" + hospitalName + ", hospitalCity=" + hospitalCity + "]";
	}
	

}
