package com.cms.app.client;

import java.util.Scanner;

import com.cms.app.dao.TrainingDAO;
import com.cms.app.dao.UserDAO;
import com.cms.app.dao.impl.TrainingDAOImpl;
import com.cms.app.dao.impl.UserDAOImpl;
import com.cms.app.model.Users;

public class TrainingAssessmentApp {

	UserDAO userDAO = new UserDAOImpl();
	String password;
	String userName;
	int sapId;
	String employeeName;
	String stream;
	int percentage;
	Scanner scanner = new Scanner(System.in);
	public TrainingAssessmentApp() {
		// TODO Auto-generated constructor stub
	}
	public void launchTrainingAssessmentApp() {
		Users user = takeUserInput();
		if(userDAO.validateUser(user)) {
			System.out.println("Valid");
			TrainingDAO trainingDAO = new TrainingDAOImpl();
			while(true) {
				System.out.println("M.E.N.U");
				System.out.println("1. Display All Training Records");
				System.out.println("2. Display Records one by one and update percentage");
				System.out.println("3. E X I T");
				int choice = 0;
				System.out.println("Please enter your choice: (1-3)");
				choice = scanner.nextInt();
				switch (choice) {
				case 1:
					System.out.println(trainingDAO.getAllTraining());
					break;
				case 2:
					System.out.println("Please update percentage: ");
					trainingDAO.getTrainingOneByOne();
					System.out.println("Update successfully");
	            case 3:
	                System.out.println("Thanks for using my app");
	                System.exit(0);
				default:
					System.out.println("Please enter (1-3)");
				}
			}
		}
		else
		{
			System.out.println("Invalid");
		}
	}
	private Users takeUserInput() {
		// TODO Auto-generated method stub
		System.out.println("Please enter User Name: ");
		userName = scanner.next();
		System.out.println("Please enter Password: ");
		password = scanner.next();
		Users user = new Users(userName, password);
		return user;
	}

}
