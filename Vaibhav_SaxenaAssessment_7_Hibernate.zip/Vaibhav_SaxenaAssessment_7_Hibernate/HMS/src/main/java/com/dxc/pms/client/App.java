package com.dxc.pms.client;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.ogm.cfg.OgmConfiguration;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {

	}
}
