package com.dxc.pms.dao;

import java.util.List;

import com.dxc.pms.entity.Doctor;

public interface HospitalDAO {

	public void add(Doctor doctor);

	public void delete(int doctorId);

	public void update(Doctor doctor);

	public Doctor getDoctor(int doctorId);

	public List<Doctor> getAllDoctor();

	public boolean isDoctorExists(int doctorId);
}
