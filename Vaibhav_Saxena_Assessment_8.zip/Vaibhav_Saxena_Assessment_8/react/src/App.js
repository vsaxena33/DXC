import React, { Component } from 'react'
import ListProductComponent from './component/ListProductComponent'
import 'bootstrap/dist/css/bootstrap.css'
import { Switch, Route } from 'react-router-dom'
import { BrowserRouter as Router } from 'react-router-dom'
import ProductComponent from './component/ProductComponent'
import SearchComponent from "./component/SearchedComponent";
import DisplayResult from "./component/DisplayResult";

export default class App extends Component {
  render() {
    return (
      <div>
        <h1>My product app</h1>
        <Router>
          <Switch>
            <Route exact path="/" component={ListProductComponent} />
            <Route exact path="/products" component={ListProductComponent} />
            <Route exact path="/products/:prodId" component={ProductComponent} />
            <Route exact path="/productSearch/:prodName" component={DisplayResult}></Route>
            <Route exact path="/productSearch" component={SearchComponent}></Route>
          </Switch>
        </Router>
      </div>
    )
  }
}