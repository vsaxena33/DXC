import React, { Component } from 'react'
import ProductDataService from '../service/ProductDataService';
import { Formik, Form, Field, ErrorMessage } from 'formik';

export default class ProductComponent extends Component {
    constructor(props) {

        super(props);
        this.state = ({
            productId: this.props.match.params.prodId,
            productName: '',
            quantityOnHand: '',
            price: '',
            boolean: false
        })
        this.onSubmit = this.onSubmit.bind(this)
    }

    UNSAFE_componentWillMount() {
        if (this.state.productId === "add")
            return;
        ProductDataService.getProduct(this.state.productId).then(
            response => {
                this.setState({
                    productName: response.data.productName,
                    quantityOnHand: response.data.quantityOnHand,
                    price: response.data.price,
                    boolean: true
                });
            }
        );
    }

    onSubmit(product) {
        if (this.state.productId === "add") {
            console.log(product);
            ProductDataService.saveProduct(product).then(response =>
                this.props.history.push('/products')
            )
        }
        else {
            console.log(product);
            ProductDataService.updateProduct(product).then(() =>
                this.props.history.push('/products')
            )
        }
    }

    validateProductFrom(values) {
        let errors = {}
        if (!values.productId) {
            errors.productId = 'Enter product Id'
        }
        else if (!values.productName) {
            errors.productName = 'Enter product Name'
        }
        else if (!values.quantityOnHand) {
            errors.quantityOnHand = 'Enter Quantity on hand'
        }
        else if (!values.price) {
            errors.price = 'Enter price'
        }
        else if (values.price < 0) {
            errors.price = 'Price can not be -ve'
        }
        else if (values.productName < 1) {
            errors.productName = 'Invalid product'
        }
        return errors
    }

    render() {
        let { productId, productName, quantityOnHand, price } = this.state
        return (
            <div>
                <h3>Update Product</h3>
                <div className="container">
                    <Formik
                        initialValues={{ productId, productName, quantityOnHand, price }}
                        enableReinitialize={true}
                        onSubmit={this.onSubmit}
                        validateOnChange={false}
                        validateOnBlur={false}
                        validate={this.validateProductFrom}>
                        <Form>
                            <ErrorMessage name="productId" component="div" className="alert alert-warning" />
                            <ErrorMessage name="productName" component="div" className="alert alert-warning" />
                            <ErrorMessage name="quantityOnHand" component="div" className="alert alert-warning" />
                            <ErrorMessage name="price" component="div" className="alert alert-warning" />
                            <fieldset className="from-group">
                                <label>Product Id</label>
                                <Field className="form-control" type="text" name="productId" disabled={this.state.boolean} />
                            </fieldset>
                            <fieldset className="from-group">
                                <label>Product Name</label>
                                <Field className="form-control" type="text" name="productName" />
                            </fieldset>
                            <fieldset className="from-group">
                                <label>Quantity On Hand</label>
                                <Field className="form-control" type="text" name="quantityOnHand" />
                            </fieldset>
                            <fieldset className="from-group">
                                <label>Price</label>
                                <Field className="form-control" type="text" name="price" />
                            </fieldset>
                            <button className="btn btn-success" type="submit">Update</button>
                        </Form>
                    </Formik>
                </div>
            </div>
        )
    }
}