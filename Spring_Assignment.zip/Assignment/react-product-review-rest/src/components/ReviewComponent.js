import React, { Component } from 'react';
import { Formik, Field, Form } from 'formik';
import ReviewDataService from '../service/ReviewDataService';



class ReviewComponent extends Component {
    constructor(props) {
        super(props);
        this.state = ({
            productId: this.props.match.params.prodId,
            reviewId: this.props.match.params.revId,
            review: '',
            reviewRating: '',
            readOnly: false,
            buttonMsg: 'Add',
            message: ''
        })
        this.onSubmit = this.onSubmit.bind(this)
    }

    componentWillMount() {
        if (this.state.reviewId === undefined) {
            this.setState({
                reviewId: ''
            })
        }
        if (this.state.reviewId !== undefined) {
            ReviewDataService.getReview(this.state.productId, this.state.reviewId).then(
                response => {
                    this.setState({
                        review: response.data.review,
                        reviewRating: response.data.reviewRating
                    })
                    this.onChangeReadOnly(this.state.reviewId)
                }
            )
        }
    }

    onChangeReadOnly(reviewId) {
        if (reviewId !== 0) {
            this.setState({
                readOnly: true,
                buttonMsg: 'Update',
            })
        }
    }

    onSubmit(review) {
        if (!this.state.readOnly) {
            ReviewDataService.addReview(review, this.state.productId).then(() =>
                this.props.history.push('/')
            ).catch(err => {
                this.setState({
                    message: 'Reveiw Id ' + review.reveiwId + ' already exists.'
                })
            })
        }
        else {
            ReviewDataService.updateReview(this.state.productId, review).then(() => this.props.history.push('/'))
        }
    }

    render() {
        let { productId, reviewId, review, reviewRating } = this.state
        return (
            <div className='container'>
                <h1>Add/Update</h1>
                <br></br>
                {this.state.message && <div className='alert alert-danger'>{this.state.message}</div>}
                <Formik initialValues={{ productId, reviewId, review, reviewRating }} enableReinitialize={true} onSubmit={this.onSubmit}>
                    <Form>
                        <fieldset className='form-group'>
                            <label>Review Id</label>
                            <Field className='form-control' type='text' name='reviewId' readOnly={this.state.readOnly}>
                            </Field>
                        </fieldset>
                        <fieldset className='form-group'>
                            <label>Review</label>
                            <Field className='form-control' type='text' name='review'>
                            </Field>
                        </fieldset>
                        <fieldset className='form-group'>
                            <label>Rating</label>
                            <Field className='form-control' type='text' name='reviewRating'>
                            </Field>
                        </fieldset>
                        <br></br>
                        <button type="submit" className='btn btn-success'>{this.state.buttonMsg}</button>
                    </Form>
                </Formik>
            </div>
        );
    }
}

export default ReviewComponent;