import React from 'react';
import ListProduct from './components/ListProduct';
import { Switch, Route } from 'react-router-dom';
import { BrowserRouter as Router } from 'react-router-dom';
import ProductComponent from './components/ProductComponent'
import './App.css'
import SearchByNameComponent from './components/SearchByNameComponent';
import NameComponent from './components/NameComponent';
import ReviewComponent from './components/ReviewComponent';




function App() {
  return (
    <div className="App">
      <h1>My Product App</h1>
      <Router>
        <Switch>
          <Route exact path="/" component={ListProduct} />
          <Route path="/productUpdate/:prodId" component={ProductComponent} />
          <Route path="/productAdd" component={ProductComponent}></Route>
          <Route path="/productSearchByName" component={SearchByNameComponent}></Route>
          <Route path="/productSearch/:prodName" component={NameComponent}></Route>


          <Route path="/reviewAdd/:prodId" component={ReviewComponent}></Route>
          <Route path="/reviewUpdate/:prodId/:revId" component={ReviewComponent}></Route>

        </Switch>
      </Router>
    </div>
  );
}

export default App;
