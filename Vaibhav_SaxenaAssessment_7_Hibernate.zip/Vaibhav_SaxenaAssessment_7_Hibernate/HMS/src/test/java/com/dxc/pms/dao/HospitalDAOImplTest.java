package com.dxc.pms.dao;

import java.util.List;

import com.dxc.pms.entity.Doctor;

import junit.framework.TestCase;

public class HospitalDAOImplTest extends TestCase {

	HospitalDAOImpl impl;
	protected void setUp() throws Exception {
		impl = new HospitalDAOImpl();
	}

	public void testAdd() {
		Doctor doctor = new Doctor(1, "Doctor", 1);
		List<Doctor> allDoctor1 = impl.getAllDoctor();
		impl.add(doctor);
		List<Doctor> allDoctor2 = impl.getAllDoctor();
		assertEquals(allDoctor1.size() + 1, allDoctor2.size());
	}

	public void testDelete() {
		List<Doctor> allDoctor1 = impl.getAllDoctor();
		impl.delete(1);
		List<Doctor> allDoctor2 = impl.getAllDoctor();
		assertEquals(allDoctor1.size() - 1, allDoctor2.size());
	}

	public void testUpdate() {
		Doctor doctor = new Doctor(2, "Doctor", 2);
		impl.add(doctor);
		Doctor newDoctor = new Doctor(2, "NewDoctor", 2);
		impl.update(newDoctor);
		assertNotSame(doctor, newDoctor);
	}

	public void testGetDoctor() {
		Doctor doctor = new Doctor(13413, "Doctor", 3);
		impl.add(doctor);
		Doctor doctor2 = impl.getDoctor(13413);
		assertEquals(doctor, doctor2);
	}

	public void testGetAllDoctor() {
		List<Doctor> allDoctor1 = impl.getAllDoctor();
		Doctor doctor1 = new Doctor(4, "Doctor1", 4);
		impl.add(doctor1);
		Doctor doctor2 = new Doctor(5, "Doctor2", 5);
		impl.add(doctor2);
		Doctor doctor3 = new Doctor(6, "Doctor3", 6);
		impl.add(doctor3);
		List<Doctor> allDoctor2 = impl.getAllDoctor();
		assertEquals(allDoctor1.size() + 3, allDoctor2.size());
	}

	public void testIsDoctorExists() {
		Doctor doctor = new Doctor(7, "Doctor", 7);
		impl.add(doctor);
		boolean value = impl.isDoctorExists(7);
		assertEquals(true, value);
	}

}
