import React, { Component } from 'react';
import ProductDataService from "../service/ProductDataService";
class DisplayResult extends Component {
  constructor(props) {
    super(props);
    this.displayProduct = this.displayProduct.bind(this);
    this.state = {
      productName: this.props.match.params.prodName,
      products: []
    };
    this.homeClicked = this.homeClicked.bind(this);
  }
  componentWillMount() {
    this.displayProduct();
  }
  displayProduct() {
    ProductDataService.searchProduct(this.state.productName).then(response => {
      this.setState({
        products: response.data
      });
      console.log(this.state.productName)
    });
  }
  homeClicked() {
    this.props.history.push(`/products`)
  }

  render() {
    return (
      <div>
        <div className="container">

          <h2>
            <center>All Products</center>
          </h2>
          <table className="table">
            <thead>
              <tr>
                <th>Product Id</th>
                <th>Product Name</th>
                <th>QuantityOnHand</th>
                <th>Price</th>

              </tr>
            </thead>

            <tbody>
              {this.state.products.map(product => (
                <tr key={product.productId}>
                  <td>{product.productId}</td>
                  <td>{product.productName}</td>
                  <td>{product.quantityOnHand}</td>
                  <td>{product.price}</td>
                </tr>
              ))}
              <td>
                <button
                  className="btn btn-primary"
                  onClick={() => this.homeClicked()}
                >
                  Home
                </button>
              </td>
            </tbody>
          </table>
        </div>
      </div>
    );
  }
}

export default DisplayResult;