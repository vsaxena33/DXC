package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.dxc.pms.model.Product;
import com.dxc.pms.service.ProductService;

@RestController
@RequestMapping("/product")
@CrossOrigin(origins = {"http://localhost:3000", "http://localhost:4200"})
public class ProductController {
	@Autowired
	ProductService productService;

	// Display all products
	@GetMapping
	public List<Product> getAllProducts() {
		System.out.println("Get All products called ");
		return productService.getProducts();
	}

	// Display product with specific productId
	@GetMapping("{productId}")
	public Product getProduct1(@PathVariable("productId") int productId) {
		System.out.println("Get product 1 called " + productId);
		return productService.getProduct(productId);
	}

	// Display product with specific productId and order id
	@GetMapping("{productId}/order/{oId}")
	public Product getProduct2(@PathVariable("productId") int productId, @PathVariable("oId") int orderId) {
		System.out.println("Get product 2 called " + productId + "orderId: " + orderId);
		return productService.getProduct(productId);
	}

	// Display product with specific product pp
	@GetMapping("/pp")
	public Product getProduct3() {
		System.out.println("Get product 3 called");
		return productService.getProduct(12);
	}

	// delete product with productid
	@DeleteMapping("{productId}")
	public boolean deleteProduct(@PathVariable("productId") int productId) {
		System.out.println("Delete Product called " + productId);
		return productService.deleteProduct(productId);
	}

	// add product
	@PostMapping()
	public boolean saveProduct(@RequestBody Product product) {
		System.out.println("Product Save called ");
		System.out.println(product);
		return productService.addProduct(product);
	}

	// update product
	@PutMapping()
	public boolean updateProduct(@RequestBody Product product) {
		System.out.println("Product Update called ");
		System.out.println(product);
		return productService.updateProduct(product);
	}

	/*
	 * @RequestMapping("/productSave") public ModelAndView productSave(Product
	 * product) { System.out.println("inside controller :"+ product);
	 * productService.addProduct(product); return new
	 * ModelAndView("success","p",product); }
	 */

}


