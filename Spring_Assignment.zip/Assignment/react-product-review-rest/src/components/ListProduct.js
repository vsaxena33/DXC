import React, { Component } from 'react';
import ProductDataService from '../service/ProductDataService';
import ReviewDataService from '../service/ReviewDataService';


class ListProduct extends Component {

    constructor(props) {
        super(props);
        this.state = ({
            products: [],
            message: '',
        })
        this.refreshProduct = this.refreshProduct.bind(this)
        this.deleteButtonClicked = this.deleteButtonClicked.bind(this)
        this.updateButtonClicked = this.updateButtonClicked.bind(this)
        this.addButtonClicked = this.addButtonClicked.bind(this)
        this.searchButtonClicked = this.searchButtonClicked.bind(this)

        this.addReviewButtonClicked = this.addReviewButtonClicked.bind(this)

    }

    componentWillMount() {
        this.refreshProduct()
    }

    refreshProduct() {
        ProductDataService.getAllProducts().then(
            response => {
                this.setState({
                    products: response.data,
                })
                console.log(response.data.length)
            }
        )
    }

    deleteButtonClicked(productId) {
        ProductDataService.deleteProduct(productId).then(
            response => {
                this.setState({
                    message: 'Product Id ' + productId + ' deleted successfully.'
                })
                this.refreshProduct()

            }
        )
    }

    addButtonClicked() {
        this.props.history.push(`/productAdd/`)
    }

    updateButtonClicked(productId) {
        this.props.history.push(`/productUpdate/${productId}`)
    }

    searchButtonClicked() {
        this.props.history.push(`/productSearchByName/`)
    }







    deleteReviewButtonClicked(productId, reviewId) {
        ReviewDataService.deleteReview(productId, reviewId).then(response => {
            this.setState({
                message: 'Review for Product Id ' + productId + ' with Review Id ' + reviewId + ' deleted successfully.'
            })
            this.refreshProduct()

        })

    }

    addReviewButtonClicked(productId) {
        this.props.history.push(`/reviewAdd/${productId}`)

    }

    updateReviewButtonClicked(productId, reviewId) {
        this.props.history.push(`/reviewUpdate/${productId}/${reviewId}`)

    }

    render() {
        return (
            <div>
                <div className='container'>
                    {this.state.message && <div className='alert alert-success'>{this.state.message}</div>}
                    <table className="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>Product Id</th>
                                <th>Product Name</th>
                                <th>Quantity On Hand</th>
                                <th>Price</th>
                                <th>Reviews</th>
                                <th>Delete/Update Product</th>
                            </tr>
                        </thead>
                        <tbody>
                            {this.state.products.map(product =>
                                <tr key={product.productId}>
                                    <td>{product.productId}</td>
                                    <td>{product.productName}</td>
                                    <td>{product.quantityOnHand}</td>
                                    <td>{product.price}</td>
                                    <td>
                                        <table className='table table-dark table-bordered'>
                                            <thead>
                                                <tr>
                                                    <th>Review Id</th>
                                                    <th>Reviews</th>
                                                    <th>Rating</th>
                                                    <th>Delete/Update Review</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {product.review.map(review =>
                                                    <tr className='table-primary' key={review.reviewId}>
                                                        <td>{review.reviewId}</td>
                                                        <td>{review.review}</td>
                                                        <td>{review.reviewRating}</td>
                                                        <td><button type="button" className="btn btn-outline-danger" onClick={() => this.deleteReviewButtonClicked(product.productId, review.reviewId)}>Delete Review</button>
                                                            <span>&nbsp;</span>
                                                            <button type="button" className="btn btn-outline-warning" onClick={() => this.updateReviewButtonClicked(product.productId, review.reviewId)}>Update Review</button></td>

                                                    </tr>)}
                                            </tbody></table>
                                        <button type="button" className='btn btn-outline-success' onClick={() => this.addReviewButtonClicked(product.productId)}>Add Review</button>&nbsp;

                                    </td>
                                    <td>
                                        <button type="button" className="btn btn-outline-danger" onClick={() => this.deleteButtonClicked(product.productId)}>Delete Product</button>
                                        <span>&nbsp;</span>
                                        <button type="button" className="btn btn-outline-warning" onClick={() => this.updateButtonClicked(product.productId)}>Update Product</button>
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                    <button type="button" className='btn btn-outline-success' onClick={() => this.addButtonClicked()}>Add Product</button>&nbsp;
                    <button type="button" className='btn btn-outline-primary' onClick={() => this.searchButtonClicked()}>Search Product By Name</button>
                </div>

            </div >
        );
    }
}

export default ListProduct;