package com.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.intThat;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.model.Product;
import com.model.Review;

public class ReviewDAOImplTest {

	ReviewDAOImpl impl;
	ProductDAOImpl productImpl;

	protected void setUp() throws Exception {
		impl = new ReviewDAOImpl();
		productImpl = new ProductDAOImpl();
	}

	@Test
	public void testGetAllReview() {
		
	}

	@Test
	public void testAddReview() {
		fail("Not yet implemented");
	}

	@Test
	public void testDeleteReview() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetReview() {
		fail("Not yet implemented");
	}

	@Test
	public void testUpdateReview() {
		fail("Not yet implemented");
	}

}
