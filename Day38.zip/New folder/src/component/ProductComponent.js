import React, { Component } from 'react'
import ProductDataService from '../service/ProductDataService';

export default class ProductComponent extends Component {
    constructor(props) {

        super(props);
        this.state = ({
            productId: this.props.match.params.prodId,
            productName:'',
            quantityOnHand:'',
            price:''
        })
    }

    componentWillMount() {
        ProductDataService.getProduct(this.state.productId).then(
            response => {
                this.setState({
                    productName : response.data.productName,
                    quantityOnHand : response.data.quantityOnHand,
                    price : response.data.price
                });
            }
        );
    }
    render() {
        return (
            <div>
                <h3>Update Product</h3>
                Product ID: {this.state.productId}<br/>
                Product Name: {this.state.productName}<br/>
                Quantity: {this.state.quantityOnHand}<br/>
                Price: {this.state.price}
            </div>
        )
    }
}
