package com.cms.app.dao;

import com.cms.app.model.Users;

public interface UserDAO {

	public boolean validateUser(Users users);
}
