package com;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductSpringRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
